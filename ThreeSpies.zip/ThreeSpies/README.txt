Credits - 
http://www.freeusandworldmaps.com/html/World_Projections/WorldPrint.html - World Map image
Original creator of 1v1v1 and for original map - SNP